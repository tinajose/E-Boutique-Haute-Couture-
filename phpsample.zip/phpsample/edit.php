<?php
	include "connection.php";
	$id=$_GET['id'];
	$sql="select * from student where id=$id";
					
	$result=mysqli_query($con,$sql);
	$row=mysqli_fetch_array($result);
	$na=$row['name'];
	$ad=$row['address'];
	$ph=$row['phone'];
	//header("location:view.php");
?>


<!doctype html>
<html>
    <head>
    <meta charset="utf-8">
    <title>Student</title>
    </head>
    
    <body>
    	
        <form method="post" action="#">
        	<h2>Edit</h2>
            <table>
            	<tr>
                	<td>Student Name</td>
                    <td>
                    	<input type="text" name="sname" value="<?php echo $na ?>"/>
                    </td>
                 </tr>
                 <tr>
                	<td>Address</td>
                    <td>
                    	<input type="text" name="address" value="<?php echo $ad ?>"/>
                    </td>
                 </tr>
                 <tr>
                	<td>Phone Number</td>
                    <td>
                    	<input type="number" name="phone" value="<?php echo $ph ?>"/>
                    </td>
                 </tr>
             </table>
             <input type="submit" name="edit" value="Edit"/>
         </form>
    </body>
</html>
<?php
	if(isset($_POST['edit']))
	{
		$sn=$_POST['sname'];
		$ad=$_POST['address'];
		$ph=$_POST['phone'];
		
		$s="update student set name='".$sn."',address='".$ad."',phone='".$ph."' where id='".$id."'";
		mysqli_query($con,$s);
		//echo $sn;
		//echo"updated successfully";
		header("location:view.php");
	}
	
	
?>