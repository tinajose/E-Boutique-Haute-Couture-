<?php
include "connection.php";
$id=$_GET['id'];
$sql="delete from student where id=$id";
mysqli_query($con,$sql);
header("location:view.php");
?>
