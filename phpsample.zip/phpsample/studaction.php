<?php
include "connection.php";
?>

<?php
	if(isset($_POST['submit']))
	{
		
		$name=$_POST['sname'];
		
		$addr=$_POST['address'];
		$ph=$_POST['phone'];
		//echo $name;
		//echo $addr;
		//echo $ph;
		mysqli_query($con,'INSERT INTO `student`(`name`, `address`, `phone`) VALUES ("'.$name.'","'.$addr.'","'.$ph.'")');
		echo "successfully inserted";
		$result="select * from student";
		$s=mysqli_query($con,$result);
				?>
                <html>
                	<body>
                    	<table border=1>
                        	<tr>
                            	<th width="130px">Name</th>
                                
                                <th width="130px">Address</th>
                                
                                <th width="130px">Phone</th>
                                
                                <th width="130px">Edit</th>
                                
                                <th width="130px">Delete</th>
                            </tr>
                         </table>
                     </body>
                </html>
                                	
                <?php
				while($row=mysqli_fetch_array($s))
				{ 
					$id=$row['id'];
					$na=$row['name'];
					$ad=$row['address'];
					$ph=$row['phone'];
?>
					<html>
                    	<body>
                        	<table border=1>
                            	<tr>
                                	<td width="130px"><?php echo $na ?></td>
                                    <td width="130px"><?php echo $ad ?></td>
                                    <td width="130px"><?php echo $ph ?></td>
                                    <td width="130px"><a href="edit.php?id=<?php echo $id ?>">Edit</a></td>
                                    <td width="130px"><a href="delete.php?id=<?php echo $id ?>">Delete</a></td>
                            	
                                </tr>
                             </table>
                        </body>
                    </html>
					<?php
				}
			
		echo "successfully Retrived";
	}
?>