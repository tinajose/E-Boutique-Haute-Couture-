<!doctype html>
<html>
    <head>
    <meta charset="utf-8">
    <title>Student</title>
    </head>
    
    <body>
    	
        <form method="post" action="studaction.php">
        	<h2>Student Registration</h2>
            <table>
            	<tr>
                	<td>Student Name</td>
                    <td>
                    	<input type="text" name="sname" val=""/>
                    </td>
                 </tr>
                 <tr>
                	<td>Address</td>
                    <td>
                    	<input type="text" name="address" val=""/>
                    </td>
                 </tr>
                 <tr>
                	<td>Phone Number</td>
                    <td>
                    	<input type="number" name="phone" val=""/>
                    </td>
                 </tr>
             </table>
             <input type="submit" name="submit"/>
         </form>
    </body>
</html>