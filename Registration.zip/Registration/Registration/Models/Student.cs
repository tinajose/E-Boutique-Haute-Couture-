﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;



namespace Registration.Models
{
    public class Student
    {
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Student Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Student Address")]
        public string Address { get; set; }
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Gender")]
        public string Gender { get; set; }
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Course")]
        public string Course { get; set; }
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Student Email")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "User Name")]
        public string Username { get; set; }
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Password")]
        public string OnlinePassword { get; set; }
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Confirm Password")]
        public string ConfirmOnlinePassword { get; set; }
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Accept the Terms and Conditions")]
        public bool isNewlyEnrolled { get; set; }
    }
    public enum Course
    {
        MCA,
        MBA,
        BCA,
        BBA
    }
}