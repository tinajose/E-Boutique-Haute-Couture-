<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JintusController extends Controller
{
    public function about()
	{
		return view('jintus.about');
	}
	public function index()
	{
		
		return view('jintus.index');
	}
	public function service()
	{
		return view('jintus.service');
	}
	public function home()
	{
		$title="Jintu";
		return view('jintus.home',compact('title'));
	}
}
