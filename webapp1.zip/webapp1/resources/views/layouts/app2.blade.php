<html>
	<body>
		<div>		
        <a href="/home">Home</a>
    	<a href="/about">About</a>
        <a href="/service">Service</a>
		</div>
        @yield('contents')
	</body>
</html>