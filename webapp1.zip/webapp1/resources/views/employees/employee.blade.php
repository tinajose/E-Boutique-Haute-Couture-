<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<form method="post" action="{{route('employee.store')}}">
    	@csrf
        Name:<input type="text" name="ename"><br/>
        Department:<input type="text" name="dept"><br/>
        Salary:<input type="text" name="salary"><br/>
        <button type="submit">Create</button>
    </form>
</body>
</html>