<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<table border="1">
	<tr>
    	<th>ID</th>
    	<th>Employee Name</th>
        <th>Department</th>
        <th>Salary</th>
     </tr>
     @foreach($employees as $employee)
     <tr>
     	<td>{{$employee->id}}</td>
        <td>{{$employee->ename}}</td>
        <td>{{$employee->dept}}</td>
        <td>{{$employee->salary}}</td>
     
     <td>
     	<a href="{{route('employee.edit',$employee->id)}}">Edit</a>
      </td>
      <td>
      
            <form method="post" action="{{route('employee.destroy',$employee->id)}}">
                @csrf
                @method('DELETE')
                <button type="submit">Delete</button>
                
            </form>
       </td>
       </tr>
       @endforeach
</table>
</body>
</html>