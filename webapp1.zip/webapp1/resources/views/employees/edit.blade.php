<form method="post" action="{{route('employee.update',$employees->id)}}">
	@method('PATCH')
    @csrf
     	Name:<input type="text" name="ename" value={{$employees->ename}}><br/>
        Department:<input type="text" name="dept" value={{$employees->dept}}><br/>
        Salary:<input type="text" name="salary" value={{$employees->salary}}><br/>
        <button type="submit">Update</button>
    </form>