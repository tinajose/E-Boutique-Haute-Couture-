<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<table border="1">
    	<tr>
        	<th>ID</th>
    		<th>Title</th>
            <th>Body</th>
        </tr>
        @foreach($books as $book)
        
        <tr>
        	<td>{{$book->id}}</td>
            <!--<td>{{$book->created_at}}</td>
            <td>{{$book->updated_at}}</td>-->
            <td>{{$book->title}}</td>
            <td>{{$book->body}}</td>
            <td>
            	<a href="{{route('book.edit',$book->id)}}">Edit</a>
            </td>
            <td>
            	<form action="{{route('book.destroy',$book->id)}}" method="post">
                	@csrf
                    @method('DELETE')
                    <button type="submit">Delete</button>
            	</form>
            </td> 
        </tr>
       @endforeach
        	
    </table>
</body>
</html>