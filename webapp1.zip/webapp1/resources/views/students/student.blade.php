<form method="post" action="{{route('student.store')}}">
@csrf
	Student Name:<input type="text" name="name">
    <br/>
    Branch:<input type="text" name="branch">
    <br/>
    Reg No:<input type="text" name="regno">
    <button type="submit">Submit</button>
</form>