
    
    	@extends('layouts.app2')
        @section('contents')
    	<h1>About</h1>
    	<h5>Amal Jyothi College Of Engineering</h5>
    	@endsection