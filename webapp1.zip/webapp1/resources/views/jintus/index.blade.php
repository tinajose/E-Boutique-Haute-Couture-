@extends('layouts.app2')
        @section('contents')
		
	<h1>This is my index page</h1>
@endsection