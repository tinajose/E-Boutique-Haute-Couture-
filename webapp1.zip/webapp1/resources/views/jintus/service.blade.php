@extends('layouts.app2')
        @section('contents')
		
	<h1>This is your service page</h1>
@endsection