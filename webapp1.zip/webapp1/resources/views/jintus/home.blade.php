@extends('layouts.app2')
        @section('contents')
        
	<h1>Home </h1>
    <h2><?php echo $title ?></h2>
@endsection