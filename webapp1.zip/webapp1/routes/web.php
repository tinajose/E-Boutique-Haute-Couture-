<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/form', function () {
    return view('Form');
});
Route::get('/hai', function () {
    return "<h1> hai friend</h1>";
});
Route::get('/users/{id}', function ($id) {
    return ' hai friend my id is'.$id;
});
Route::get('/about', function () {
    return view('jintus.about');
});
//Route::get('/tina', function () {
//    return view('books.book');
//});
Route::get('/stud', function () {
    return view('students.student');
});
Auth::routes();

Route::get('/homes', 'HomeController@index')->name('home');
Route::get('/about', 'JintusController@about');
Route::get('/index', 'JintusController@index');
Route::get('/service', 'JintusController@service');
Route::get('/home', 'JintusController@home');
//Route::get('/sample','BooksController@sample');
Route::resource('/book','BooksController');
Route::resource('/student','StudentsController');
Route::resource('/employee','EmployeesController');
