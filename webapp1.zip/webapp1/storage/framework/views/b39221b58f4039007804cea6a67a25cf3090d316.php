<html>
	<body>
		<div>		
        <a href="/home">Home</a>
    	<a href="/about">About</a>
        <a href="/service">Service</a>
		</div>
        <?php echo $__env->yieldContent('contents'); ?>
	</body>
</html>