<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<table border="1">
	<tr>
    	<th>ID</th>
    	<th>Employee Name</th>
        <th>Department</th>
        <th>Salary</th>
     </tr>
     <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
     	<td><?php echo e($employee->id); ?></td>
        <td><?php echo e($employee->ename); ?></td>
        <td><?php echo e($employee->dept); ?></td>
        <td><?php echo e($employee->salary); ?></td>
     
     <td>
     	<a href="<?php echo e(route('employee.edit',$employee->id)); ?>">Edit</a>
      </td>
      <td>
      
            <form method="post" action="<?php echo e(route('employee.destroy',$employee->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit">Delete</button>
                
            </form>
       </td>
       </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>