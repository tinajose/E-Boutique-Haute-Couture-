<form method="post" action="<?php echo e(route('book.update',$books->id)); ?>">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>
	Title:<input type="text" name="title" value=<?php echo e($books->title); ?>>
    <br/>
    Body:<input type="text" name="body" value=<?php echo e($books->body); ?>>
    <br/>
    <button type="submit">Update</button>
</form>