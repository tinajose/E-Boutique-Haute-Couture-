        <?php $__env->startSection('contents'); ?>
        
	<h1>Home </h1>
    <h2><?php echo $title ?></h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>