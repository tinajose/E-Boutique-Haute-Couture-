<form method="post" action="<?php echo e(route('employee.update',$employees->id)); ?>">
	<?php echo method_field('PATCH'); ?>
    <?php echo csrf_field(); ?>
     	Name:<input type="text" name="ename" value=<?php echo e($employees->ename); ?>><br/>
        Department:<input type="text" name="dept" value=<?php echo e($employees->dept); ?>><br/>
        Salary:<input type="text" name="salary" value=<?php echo e($employees->salary); ?>><br/>
        <button type="submit">Update</button>
    </form>