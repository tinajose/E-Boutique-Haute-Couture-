<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<table border="1">
    	<tr>
        	<th>ID</th>
    		<th>Title</th>
            <th>Body</th>
        </tr>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr>
        	<td><?php echo e($book->id); ?></td>
            <!--<td><?php echo e($book->created_at); ?></td>
            <td><?php echo e($book->updated_at); ?></td>-->
            <td><?php echo e($book->title); ?></td>
            <td><?php echo e($book->body); ?></td>
            <td>
            	<a href="<?php echo e(route('book.edit',$book->id)); ?>">Edit</a>
            </td>
            <td>
            	<form action="<?php echo e(route('book.destroy',$book->id)); ?>" method="post">
                	<?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Delete</button>
            	</form>
            </td> 
        </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        	
    </table>
</body>
</html>