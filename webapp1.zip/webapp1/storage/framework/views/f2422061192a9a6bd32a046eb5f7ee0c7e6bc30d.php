<form method="post" action="<?php echo e(route('book.store')); ?>">
<?php echo csrf_field(); ?>
	Title:<input type="text" name="title">
    <br/>
    Body:<input type="text" name="body">
    <br/>
    <button type="submit">Add</button>
</form>