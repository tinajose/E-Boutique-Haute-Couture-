﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcDatabaseApp.Models
{
    public class Customer
    {
        public int CustomerID { get; set; }
        [Required(ErrorMessage="Can't be empty")]
        [Display(Name="Customer Name")]
        
        public string Cname { get; set; }
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Customer Address")]
        public string Caddress { get; set; }
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Customer Email")]
        public string Cemail { get; set; }
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "User Name")]
        public string Cusername { get; set; }
        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Password")]
        public string Cpassword { get; set; }

    }
}