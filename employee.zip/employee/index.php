<?php
	
	$con=mysqli_connect("localhost","root","","sample");
	if($con)
	{
		//echo"success";
	}
	else
	{
		echo"not success";
	}
?>
<!doctype html>
<html>
    <head>
    	<style>
			input[type=text]
			{
				width: 250px;
				padding: 15px;
				margin: 5px 0 22px 0;
				display: inline-block;
				border: none;
				background: #f1f1f1;
				border-radius: 12px;
			}
			input[type=submit] 
			{
				width: 350px;
				padding: 15px;
				margin: 5px 0 22px 0;
				display: inline-block;
				border: none;
				background:#F03;
				border-radius: 12px;	
			}
			select
			{
				width: 300px;
				padding: 15px;
				margin: 5px 0 22px 0;
				display: inline-block;
				border: none;
				background: #f1f1f1;
				border-radius: 12px;
			}
			h1
			{
				
				color:#333;
			}
		</style>

        <meta charset="utf-8">
        <title>Untitled Document</title>
    </head>
    
    <body>
    
    <center>
    	<h1>Employee Details</h1>
    	<form action="#" method="post">
        	<table>
            	<tr>
                	<th>Employee Name</th>
                    <td><input type="text" name="ename" autocomplete="off"/></td>
                </tr>
                  
                
                </tr>	
            	<tr>
                	<th>Select Country</th>
                    <td><select id="countrydd" name="countrydd" onChange="change_country()">
                    		<option>--Select Country--</option>
                            <?php
								$res=mysqli_query($con,"select * from country");
								while($row=mysqli_fetch_array($res))
								{
									
							?>
                            
            				<option value="<?php echo $row["cid"];?>"><?php echo $row["cname"]; ?></option>
                            <?php
								}
							?>
                            </select>
                     </td>
                 </tr>
                 <tr>
                 	<th>Select State</th>
                    <td>
                    	<div id="state">
                    	<select id="statedd" name="statedd">
                        	<option> --Select State--</option>
                         </select>
                         </div>
                    </td>
                  </tr>
                  <tr>
                 	<th>Select District</th>
                    <td>
                    	<div id="district">
                    	<select id="districtdd" name="districtdd">
                        	<option> --Select District--</option>
                         </select>
                         </div>
                    </td>
                  </tr>
                  
              </table>
              <input type="submit" name="submit"/>
                        
        </form>
        </center>
        <script type="text/javascript">
			function change_country()
			{
					var xmlhttp=new XMLHttpRequest();
					//xmlhttp.open("GET","ajax.php?country=" + document.getElementsByName("countrydd").value,false);
					xmlhttp.open("GET","ajax.php?country=" + document.getElementById("countrydd").value,false);
					xmlhttp.send(null);
					//document.getElementsByName("state").innerHTML=xmlhttp.responseText;
					document.getElementById("state").innerHTML=xmlhttp.responseText;
					
			}
			function change_state()
			{
					var xmlhttp=new XMLHttpRequest();
					xmlhttp.open("GET","ajax2.php?state=" + document.getElementById("statedd").value,false);
					xmlhttp.send(null);
					//document.getElementsByName("district").innerHTML=xmlhttp.responseText;

					document.getElementById("district").innerHTML=xmlhttp.responseText;
					
			}
		</script>
    </body>
</html>
<?php
	if(isset($_POST['submit']))
	{
		$name=$_POST['ename'];
		$country=$_POST['countrydd'];
		$state=$_POST['statedd'];
		$dis=$_POST['districtdd'];
		mysqli_query($con,"INSERT INTO `employee`(`ename`, `country`, `state`, `district`) VALUES ('".$name."','".$country."','".$state."','".$dis."')");
		
		echo"success";
	}

?>
